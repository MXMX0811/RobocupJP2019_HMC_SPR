#! /usr/bin/env python
# -*- coding: utf-8 -*-
'''
Date: 2018/03/02
Author: Xu Yucheng
Abstract： 订阅输出Pocketsphinx识别结果的话题，然后根据输出的结果来控制机器人
'''

import roslib
'''
roslib.load_manifest ('speech')
roslib.load_manifest () reads the package manifest and sets up the python library path based on the package dependencies.
It's required for older rosbuild-based packages, but is no longer needed on catki
'''
import rospy
from std_msgs.msg import String
from std_msgs.msg import Int8
import os
import sys
import time
import wave
import datetime
import pyaudio
import random
from kamerider_speech.msg import mission
from sound_play.libsoundplay import SoundClient
from read_xml_files import main as read_main
from kamerider_image_msgs.msg import GenderDetection
from play_signal_sound import play_signal_sound

# 定义表示任务状态的变量
UNSTART = 0
PROCESS = 1
FINISH  = 2

class gpsr_speech_control(object):
    """Class to read the recognition output of pocketsphinx"""
    def __init__(self):
        rospy.on_shutdown(self.cleanup)
        # Default infomations
        self.gestures, self.locations, self.names, self.objects = read_main()
        # Type of task
        self.task_type = ['person', 'object', 'object2person', 'Q&A']
        # State of task
        self.task_state = [UNSTART, PROCESS, FINISH]
        # Predefined missions
        self.missions = ['put', 'bring', 'take', 'guide', 'find', 'answer', 'introduce',
                         'grasp', 'get', 'give', 'tell', 'navigate', 'look', 'deliver']
        self.months = ['january', 'february', 'march', 'april', 'may', 'june', 'july',
                        'august', 'september', 'october', 'november', 'december']
        # Define parameters
        self.voice = None
        self.question_start_signal = None
        self.cmd_files = None
        # Publisher topics
        self.pub_to_nav_topic_name = None
        self.pub_to_image_topic_name = None
        self.pub_to_arm_topic_name = None
        self.pub_riddle_finish_topic_name = None
        # Subscriber topics
        self.sub_nav_back_topic_name = None
        self.sub_image_back_topic_name = None
        self.sub_arm_back_topic_name = None
        self.sub_xfei_back_topic_name=None
        self.sub_gender_recognition_topic_name=None
        self.sub_pocketsphinx_topic_name = None

        # Mission keywords
        self.target_room = None
        self.target_location = None
        self.target_person = None
        self.target_object = None
        self.target_mission = None
        # Mission keywords
        self._room = UNSTART
        self._location = UNSTART
        self._person = UNSTART
        self._object = UNSTART
        self._mission = UNSTART

        #Question count
        self.question_num = 1
        self.is_answer_question = False
        self.ask_times = 1
        #Gender detection results
        self.male_number = 0
        self.female_number = 0
        self.stand_number = 0
        self.sit_number = 0

        #Kws list
        self.kws_list = []

        self.init_params()
        self.get_params()

    def init_params(self):
        # Mission keywords
        self.target_room = None
        self.target_location = None
        self.target_person = None
        self.target_object = None
        self.target_mission = None
        # Mission state
        self._room = UNSTART
        self._location = UNSTART
        self._person = UNSTART
        self._object = UNSTART
        self._mission = UNSTART

    def get_params(self):
        # Initialize sound client
        self.sh = SoundClient(blocking = True)
        rospy.sleep(1)
        self.sh.stopAll()
        rospy.sleep(1)

        # Get parameters
        self.voice = rospy.get_param("~voice", "voice_kal_diphone")
        #self.voice = rospy.get_param("~voice", "voice_cmu_us_clb_arctic_clinuts")
        self.cmd_files = rospy.get_param("~cmd_file", "/home/kamerider/catkin_ws/src/kamerider_speech/CommonFiles")

        self.pub_to_arm_topic_name   = rospy.get_param("pub_to_arm_topic_name"  , "/speech_to_arm")
        self.pub_to_nav_topic_name   = rospy.get_param("pub_to_nav_topic_name"  , "/speech_to_nav")
        self.pub_to_image_topic_name = rospy.get_param("pub_to_image_topic_name", "/speech_to_image")
        self.pub_riddle_finish_topic_name = rospy.get_param("pub_riddle_finish_topic_name", "/riddle_finish")

        self.sub_arm_back_topic_name   = rospy.get_param("sub_arm_back_topic_name"  , "/arm_to_speech")
        self.sub_nav_back_topic_name   = rospy.get_param("sub_nav_back_topic_name"  , "/nav_to_speech")
        self.sub_image_back_topic_name = rospy.get_param("sub_image_back_topic_name", "/image_to_speech")
        #self.sub_xfei_back_topic_name  = rospy.get_param("sub_xfei_back_topic_name" , "/xfei_output")
        self.sub_xfei_back_topic_name  = rospy.get_param("sub_xfei_back_topic_name" , "/baidu_to_control")
        self.sub_gender_recognition_topic_name = rospy.get_param('sub_gender_recognition_topic_name', '/gender_recognition_result')
        self.sub_pocketsphinx_topic_name = rospy.get_param("sub_pocketsphinx_topic_name","/kws_data")

        rospy.Subscriber(self.sub_arm_back_topic_name, String, self.armCallback)
        rospy.Subscriber(self.sub_nav_back_topic_name, String, self.navCallback)
        rospy.Subscriber(self.sub_image_back_topic_name, String, self.imageCallback)
        rospy.Subscriber(self.sub_xfei_back_topic_name, String, self.xfeiCallback)
        rospy.Subscriber(self.sub_gender_recognition_topic_name, GenderDetection, self.genderCallback)
        rospy.Subscriber(self.sub_pocketsphinx_topic_name, String, self.pocketsphinxCallback)

        self.arm_pub   = rospy.Publisher(self.pub_to_arm_topic_name, String, queue_size=1)
        self.nav_pub   = rospy.Publisher(self.pub_to_nav_topic_name, String, queue_size=1)
        self.image_pub = rospy.Publisher(self.pub_to_image_topic_name, String, queue_size=1)
        self.riddle_finish_pub = rospy.Publisher(self.pub_riddle_finish_topic_name, String, queue_size = 1)

        # Start gpsr task
        #self.start_gpsr()

    def publishr_message(self, pub, msg):
        # 接受一个发布器和待发布的消息
        pub.publish(msg)

    def start_gpsr(self):
        # 播放初始化的音频，并提醒操作者如何使用语音操作Jack
        rospy.sleep(1)
        self.sh.say("Hello my name is Jack", self.voice)
        rospy.sleep(3)
        self.sh.say("Please say Jack to wake me up before each question", self.voice)
        rospy.sleep(5)
        self.sh.say("I am ready for your command if you hear", self.voice)
        rospy.sleep(3.5)
        play_signal_sound()

    def pocketsphinxCallback(self,msg):
        self.kws_list.append(msg.data)
        print self.kws_list
        print("==================")

    def armCallback(self, msg):
        if msg.data == "object_target_grasped":
            self._object = FINISH

    def navCallback(self, msg):
        if msg.data == "room_target_arrived":
            self._room = FINISH
        if msg.data == "loc_target_arrived":
            self._location = FINISH

    def imageCallback(self, msg):
        if msg.data == "person_target_found":
            self._person = FINISH

    def genderCallback(self, msg):
        self.male_number = msg.male_num
        self.female_number = msg.female_num
        self.sit_number = msg.sit_num
        self.stand_number = msg.stand_num
        #print("male number is", self.male_number)
        #print("female number is", self.female_number)
        #print("sit_number is", self.sit_number)
        #print("stand number is", self.stand_number)

    def xfeiCallback(self, msg):
        #TODO
        #没有识别到，若可以要求重新问记得改
        if msg.data.strip()=='':
            #self.sh.say("I did not clearly hear your question", self.voice)
            #self.sh.say("please ask me again", self.voice)
            #self.ask_times = 2
            self.is_answer_question = False
        else:
            string = msg.data
            symbols = ["!", "?", ".", ",", ";", ":"]
            output = []
            if string[-1] in symbols:
                string = string[:-1]
            for part in string.lstrip().split(","):
                for word in part.split():
                    for symbol in symbols:
                        if symbol in word:
                            word = word[:-1]
                    output.append(word)
            output = [item.lower() for item in output]
            print (output)
            #self.question_num += 1
            self.answer_question(output)

            self.kws_list = []

        if self.is_answer_question:
            self.question_num += 1
            self.ask_times = 1
            self.is_answer_question = False
            #print("111111111111111")
        elif self.ask_times == 1:
            self.sh.say("I did not clearly hear your question", self.voice)
            self.sh.say("please ask me again", self.voice)
            self.ask_times = 2
            #print("222222222222222")
        else:
            self.sh.say("I don't understand your question", self.voice)
            self.sh.say("please ask me the next question", self.voice)
            self.question_num += 1
            self.ask_times = 1
            self.is_answer_question = False
            #print("333333333333333")
            
        print("================================")
        print("Question NO.%d (%d)"%(self.question_num, self.ask_times))
        #print("================================")
        if self.question_num -1 == 5:
            if self.ask_times == 1:
                pub_msg = "riddle_half"
                self.publishr_message(self.riddle_finish_pub, pub_msg)
                print('[INFO] SUCCESSFULLY PUBLISH riddle_half MESSAGE')
        if self.question_num -1 == 10:
            if self.ask_times == 1:
                pub_msg = "riddle_finish"
                self.publishr_message(self.riddle_finish_pub, pub_msg)
                print('[INFO] SUCCESSFULLY PUBLISH riddle_finish MESSAGE')




    # 定义完成任务的函数，首先是移动到指定房间, 然后指定地点，然后找到指定人或者物体
    '''def move_to_room(self):
        msg = mission()
        msg.mission_type = 'room'
        msg.mission_name = str(self.target_room)
        if self._room == UNSTART:
            self.publishr_message(self.nav_pub, msg)
            self._room = PROCESS

    def move_to_location(self):
        msg = mission()
        msg.mission_type = 'location'
        msg.mission_name = str(self.target_location)
        if self._location == UNSTART:
            self.publishr_message(self.nav_pub, msg)
            self._location = PROCESS

    def find_person(self):
        msg = mission()
        msg.target_type = 'person'
        msg.mission_name = str(self.target_person)
        if self._person == UNSTART:
            self.publishr_message(self.image_pub, msg)
            self._person = PROCESS

    def find_object(self):
        msg = mission()
        msg.target_type = 'object'
        msg.mission_name = str(self.target_object)
        if self._object == UNSTART:
            self.publishr_message(self.image_pub, msg)
            self._object = PROCESS
    '''
    def answer_question(self, output):
        self.is_answer_question = False
        self.sh.stopAll()

        #questions about the arena
        if "bedroom" in output:
            if "how" in output or "many" in output or "furniture" in output or "furnitures" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is that there are 7 furnitures", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "name" in output or "list" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is that bed, neight table and wardrobe", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            else:
                r = random.randint(1,2)
                if r == 1:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("The answer is that there are 7 furnitures", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True
                else:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("The answer is that bed, neight table and wardrobe", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True

        if "dining" in output:
            if "how" in output or "many" in output or "furniture" in output or "furnitures" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is that there are 5 furnitures", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "name" in output or "list" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is that sideboard, dining table and chair", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            else:
                r = random.randint(1,2)
                if r == 1:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("The answer is that there are 5 furnitures", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True
                else:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("The answer is that sideboard, dining table and chair", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True

        if "living" in output:
            if "how" in output or "many" in output or "furniture" in output or "furnitures" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is that there are 7 furnitures", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "name" in output or "list" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is that bookshelf, sofa and center table", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "kitchen" in output:
            if "how" in output or "many" in output or "furniture" in output or "furnitures" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is that there are 10 furnitures", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "name" in output or "list" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is that microwave, cupboard and counter", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "corridor" in output or "college" in output:
            if "how" in output or "many" in output or "furniture" in output or "furnitures" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is that there are 1 furnitures", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "what" in output or "list" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is that cabinet", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "bathroom" in output or "bath" in output:
            if "how" in output or "many" in output or "furniture" in output or "furnitures" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is that there are 7 furnitures", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "name" in output or "list" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is that bidet, shower and bathtub", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        #questions of the official objects 
        
        if "soap" in output or "soup" in output or "shampoo" in output or "cloth" in output or "sponge" in output or "toothpaste" in output:
            if "where" in output or "location" in output or "room" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is on the bathroom cabinet", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            if "kind" in output or "belong" in output or "category" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is toiletries", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
        
        if "chips" in output or "m" in output or "cookies" in output or "pringles" in output:
            if "where" in output or "location" in output or "room" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is on the center table of living room", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            if "kind" in output or "belong" in output or "category" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is snacks", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "apple" in output or "banana" in output or "melon" in output or "pear" in output or "peach" in output:
            if "where" in output or "location" in output or "room" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is on the dining table of dining room", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            if "kind" in output or "belong" in output or "category" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is fruits", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True


        if "pasta" in output or "noodles" in output or "tuna fish" in output or "pickles" in output:
            if "where" in output or "location" in output or "room" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is in the cabinet of kitchen", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            if "kind" in output or "belong" in output or "category" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is food", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "choco" in output or "flakes" in output or "flake" in output or "muesli" in output or "robo" in output:
            if "where" in output or "location" in output or "room" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is in the cupboard of kitchen", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            if "kind" in output or "belong" in output or "category" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is food", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "tea" in output or "beer" in output or "coke" in output or "water" in output or "milk" in output or "bear" in output:
            if "where" in output or "location" in output or "room" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is in the fridge of kitchen", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            if "kind" in output or "belong" in output or "category" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is drink", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "spoon" in output or "folk" in output or "knife" in output or "napkin" in output:
            if "where" in output or "location" in output or "room" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is in cutlery drawer of dining room", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            if "kind" in output or "belong" in output or "category" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is cultery", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "dish" in output or "bowl" in output or "glass" in output or "mug" in output or "mark" in output or "bow" in output:
            if "where" in output or "location" in output or "room" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is in sideboard of dining room", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            if "kind" in output or "belong" in output or "category" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is tableware", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "tray" in output or "box" in output or "bag" in output or "tree" in output:
            if "where" in output or "location" in output or "room" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is in counter of kitchen", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            if "kind" in output or "belong" in output or "category" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("The answer is containers", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            
        #predefined questions
        if "royal" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("When was The Royal Canadian Mounted Police formed", self.voice)
            self.sh.say("The answer is In 1920, when The Mounted Police merged with the Dominion Police", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True

        if "domestic" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("Which robot is used in the Domestic Standard Platform League", self.voice)
            self.sh.say("The answer is The Toyota Human Support Robot", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True

        if "social" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("Which robot is used in the Social Standard Platform League", self.voice)
            self.sh.say("The answer is The SoftBank Robotics Pepper", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True

        if "usa" in output or "year" in output:
            if "first" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("In which year was Canada invaded by the USA for the first time", self.voice)
                self.sh.say("The answer is The first time that the USA invaded Canada was in 1775", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            else:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("What year was Canada invaded by the USA for the second time", self.voice)
                self.sh.say("The answer is The USA invaded Canada a second time in 1812", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "b" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("When was the B programming language invented", self.voice)
            self.sh.say("The answer is B was developed circa 1969 at Bell Labs", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True

        if "program" in output or "programming" in output or "programmer" in output:
            if "who" in output:
                if "c" in output or "same" in output:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("Who invented the C programming language", self.voice)
                    self.sh.say("The answer is Ken Thompson and Dennis Ritchie", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True
                if "python" in output or "poison" in output:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("Who created the Python Programming Language", self.voice)
                    self.sh.say("The answer is Python was invented by Guido van Rossum", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True
                if "first" in output:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("Who is considered to be the first computer programmer", self.voice)
                    self.sh.say("The answer is Ada Lovelace", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True

                else:
                    r = random.randint(1,3)
                    if r == 1:
                        self.sh.say("I heard the question", self.voice)
                        self.sh.say("Who invented the C programming language", self.voice)
                        self.sh.say("The answer is Ken Thompson and Dennis Ritchie", self.voice)
                        self.sh.say("Okay i am ready for your next question", self.voice)
                        self.is_answer_question = True
                    elif r == 2:
                        self.sh.say("I heard the question", self.voice)
                        self.sh.say("Who created the Python Programming Language", self.voice)
                        self.sh.say("The answer is Python was invented by Guido van Rossum", self.voice)
                        self.sh.say("Okay i am ready for your next question", self.voice)
                        self.is_answer_question = True

                    else:
                        self.sh.say("I heard the question", self.voice)
                        self.sh.say("Who is considered to be the first computer programmer", self.voice)
                        self.sh.say("The answer is Ada Lovelace", self.voice)
                        self.sh.say("Okay i am ready for your next question", self.voice)
                        self.is_answer_question = True

            if "when" in output:
                if "c" in output or "same" in output:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("When was the C programming language invented", self.voice)
                    self.sh.say("The answer is C was developed after B in 1972 at Bell Labs", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True
                if "b" in output or "big" in output:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("When was the B programming language invented", self.voice)
                    self.sh.say("The answer is B was developed circa 1969 at Bell Labs", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True
            if "which" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Which program do Jedi use to open PDF files", self.voice)
                self.sh.say("The answer is Adobe Wan Kenobi", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            else:
                if "c" in output or "same" in output:
                    pass

        if "computer" in output:
            if "but" in output or "bug" in output or "by" in output or "back" in output:
                if "where" in output:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("Where does the term computer bug come from", self.voice)
                    self.sh.say("The answer is From a moth trapped in a relay", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True
                if "first" in output:
                    self.sh.say("I heard the question", self.voice)
                    #bug识别为back bag
                    self.sh.say("What was the first computer bug", self.voice)
                    self.sh.say("The answer is The first actual computer bug was a dead moth stuck in a Harvard Mark 2", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True


            if "test" in output or "pass" in output or "tests" in output or "first" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("What was the first computer in pass the Turing test", self.voice)
                self.sh.say("The answer is Some people think it was IBM Watson, but it was Eugene, a computer designed at England's University of Reading", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "come" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("Where does the term computer bug come from", self.voice)
            self.sh.say("The answer is From a moth trapped in a relay", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True

        if "compile" in output or "compiler" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("Who invented the first compiler", self.voice)
            self.sh.say("The answer is Grace Brewster Murray Hopper invented it", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        
        if "open" in output and "play" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("Which robot is used in the Open Platform League", self.voice)
            self.sh.say("The answer is There is no standard defined for OPL", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True

        if "platform" in output:
            if "open" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Which robot is used in the Open Platform League", self.voice)
                self.sh.say("The answer is There is no standard defined for OPL", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "domestic" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Which robot is used in the Domestic Standard Platform League", self.voice)
                self.sh.say("The answer is The Toyota Human Support Robot", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "social" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Which robot is used in the Social Standard Platform League", self.voice)
                self.sh.say("The answer is The SoftBank Robotics Pepper", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
        if "name" in output and "team" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("What's the name of your team", self.voice)
            self.sh.say("The answer is kamerider", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "time" in output and len(output) < 6:
            curr_time = str(time.strftime('%H:%M:%S'))
            self.sh.say("I heard the question", self.voice)
            self.sh.say("What time is it", self.voice)
            self.sh.say("The answer is "+curr_time, self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "day" in output or "today" in output:
            today = datetime.date.today()
            today = today.strftime("%Y-%m-%d")
            year = today[0]
            month = today
            self.sh.say("I heard the question", self.voice)
            self.sh.say("What day is today", self.voice)
            self.sh.say("The answer is "+today, self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "dream" in output or "dreams" in output or "have" in output or "Have" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("Do you have dreams", self.voice)
            self.sh.say("The answer is I dream of Electric Sheep", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "city" in output and "next" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("In which city will next year's RoboCup be hosted", self.voice)
            self.sh.say("The answer is It hasn't been announced yet", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "canada" in output:
            if "origin" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("What is the origin of the name Canada", self.voice)
                self.sh.say("The answer is The name Canada comes from the Iroquois word Kanata, meaning village or settlement", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "capital" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("What is the capital of Canada", self.voice)
                self.sh.say("The answer is The capital of Canada is Ottawa", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "national" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("What is the national anthem of Canada", self.voice)
                self.sh.say("The answer is O Canada", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "handsome" in output or "person" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Who's the most handsome person in Canada", self.voice)
                self.sh.say("The answer is that Justin Trudeau is very handsome", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if ("time" in output or "many" in output) and len(output) < 9 or "those" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("How many time zones are there in Canada", self.voice)
                self.sh.say("The answer is Canada spans almost 10 million square km and comprises 6 time zones", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "usa" in output or "year" in output:
                if "first" in output:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("In which year was Canada invaded by the USA for the first time", self.voice)
                    self.sh.say("The answer is The first time that the USA invaded Canada was in 1775", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True
                if "second" in output:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("What year was Canada invaded by the USA for the second time", self.voice)
                    self.sh.say("The answer is The USA invaded Canada a second time in 1812", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True
            if "why" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Why is Canada named Canada", self.voice)
                self.sh.say("The answer is French explorers misunderstood the local native word Kanata, which means village", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            if "named" in output and "cananda" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Why is Canada named Canada", self.voice)
                self.sh.say("The answer is French explorers misunderstood the local native word Kanata, which means village", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            if "desert" in output:
                self.sh.say("I heard the question", self.voice)
                #canada有？
                self.sh.say("Where is Canada's only desert", self.voice)
                self.sh.say("The answer is Canada's only desert is British Columbia", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "world" in output or "word" in output or "worlds" in output or "words" in output or "world's" in output:
            if "longest" in output or "street" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("What's the longest street in the world", self.voice)
                self.sh.say("The answer is Yonge Street in Ontario is the longest street in the world", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "largest" in output or "coin" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("What is the world's largest coin", self.voice)
                self.sh.say("The answer is The Big Nickel in Sudbury, Ontario. It is nine meters in diameter", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
        if "street" in output and "how" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("How long is Yonge Street in Ontario", self.voice)
            self.sh.say("The answer is Yonge street is almost 2,000 km, starting at Lake Ontario, and running north to the Minnesota border", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "london" in output and "name" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("What's the name of the bear cub exported from Canada to the London Zoo in 1915", self.voice)
            self.sh.say("The answer is The bear cub was named Winnipeg. It inspired the stories of Winnie-the-Pooh", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "smartphone" in output or "smart" in output or "phone" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("Where was the Blackberry Smartphone developed", self.voice)
            self.sh.say("The answer is It was developed in Ontario, at Research In Motion's Waterloo offices", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "country" in output:
            if "record" in output or "gold" in output or "winter" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("What country holds the record for the most gold medals at the Winter Olympics", self.voice)
                self.sh.say("The answer is Canada does! With 14 Golds at the 2010 Vancouver Winter Olympics", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "gold" in output or "medals" in output or "winter" in output or "olympics" in output or "record" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("What country holds the record for the most gold medals at the Winter Olympics", self.voice)
            self.sh.say("The answer is Canada does! With 14 Golds at the 2010 Vancouver Winter Olympics", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True


        if "who" in output and "coined" in output:
            if "term" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Who coined the term Beatlemenia", self.voice)
                self.sh.say("Sandy Gardiner, a journilist of the Ottawa Journal", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
        if "mounted" in output or "police" in output or "place" in output:
            if "royal" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("When was The Royal Canadian Mounted Police formed", self.voice)
                self.sh.say("The answer is In 1920, when The Mounted Police merged with the Dominion Police", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            else:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("When was The Mounted Police formed", self.voice)
                self.sh.say("The answer is The Mounted Police was formed in 1873", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
        if "how" in output and "big" in output:
            if "RCMP" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("How big is the RCMP", self.voice)
                self.sh.say("The answer is Today, the RCMP has close to 30,000 members", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "canada" in output or "desert" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("How big is Canada's only desert", self.voice)
                self.sh.say("The answer is The British Columbia desert is only 15 miles long", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
        if "montreal" in output or "else" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("What else is Montreal called", self.voice)
            self.sh.say("The answer is Montreal is often called the City of Saints or the City of a Hundred Bell Towers", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True

        if "snow" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("How many tons of snow are required to build The Hotel de Glace", self.voice)
            self.sh.say("The answer is Every year, 12000 tons of snow are used for The Hotel de Glace", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True

        if "hotel" in output:
            if "where" in output or "located" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Where is The Hotel de Glace located", self.voice)
                self.sh.say("The answer is The Hotel de Glace is in Quebec", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "how" in output or "many" in output:
                if "ice" in output or "see" in output or "eye" in output or "eyes" in output:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("How many tons of ice are required to build The Hotel de Glace", self.voice)
                    self.sh.say("The answer is The Hotel de Glace requires about 400 tons of ice", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True
                if "snow" in output:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("How many tons of snow are required to build The Hotel de Glace", self.voice)
                    self.sh.say("The answer is Every year, 12000 tons of snow are used for The Hotel de Glace", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True
            if "can" in output or "visit" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Can I visit the Hotel de Glace in summer", self.voice)
                self.sh.say("The answer is No. Every summer it melts away, only to be rebuilt the following winter", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "summer" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("Can I visit the Hotel de Glace in summer", self.voice)
            self.sh.say("The answer is No. Every summer it melts away, only to be rebuilt the following winter", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True


        if "name" in output:
            if "famous" in output:
                if "male" in output:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("Name 3 famous male Canadians", self.voice)
                    self.sh.say("The answer is Leonard Cohen, Keanu Reeves, and Jim Carrey", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True
                if "female" in output:
                    self.sh.say("I heard the question", self.voice)
                    self.sh.say("Name 3 famous female Canadians", self.voice)
                    self.sh.say("The answer is Celine Dion, Pamela Anderson, and Avril Lavigne", self.voice)
                    self.sh.say("Okay i am ready for your next question", self.voice)
                    self.is_answer_question = True
            if "robots" in output or "all" in output or "robot" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Name all of the robots on Mars", self.voice)
                self.sh.say("The answer is There are four robots on Mars: Sojourner, Spirit, Opportunity, and Curiosity. Three more crashed on landing", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "math" in output or "mars" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("Name all of the robots on Mars", self.voice)
            self.sh.say("The answer is There are four robots on Mars: Sojourner, Spirit, Opportunity, and Curiosity. Three more crashed on landing", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True



        if "famous" in output:
            if "male" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Name 3 famous male Canadians", self.voice)
                self.sh.say("The answer is Leonard Cohen, Keanu Reeves, and Jim Carrey", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

            else:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Name 3 famous female Canadians", self.voice)
                self.sh.say("The answer is Celine Dion, Pamela Anderson, and Avril Lavigne", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if ("what" in output or "what's" in output) and "origin" in output:
            if "comic" in output or "font" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("What's the origin of the Comic Sans font", self.voice)
                self.sh.say("The answer is Comic Sans is based on Dave Gibbons' lettering in the Watchmen comic books", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "comic" in output or "college" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("What's the origin of the Comic Sans font", self.voice)
            self.sh.say("The answer is Comic Sans is based on Dave Gibbons' lettering in the Watchmen comic books", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True

        if "nanobot" in output or "nano" in output or "another" in output or "none" in output:
            if "what" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("what is a nanobot", self.voice)
                self.sh.say("The answer is The Hotel de Glace is in Quebec", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "how" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("How small can a nanobot be", self.voice)
                self.sh.say("The answer is A nanobot can be less than one-thousandth of a millimeter", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
        if "why" in output and "award" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("Why wasn't Tron nominated for an award by The Motion Picture Academy", self.voice)
            self.sh.say("The answer is The Academy thought that Tron cheated by using computers", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True

        if "motion" in output or "picture" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("Why wasn't Tron nominated for an award by The Motion Picture Academy", self.voice)
            self.sh.say("The answer is The Academy thought that Tron cheated by using computers", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True

        if "hard" in output and "disk" in output:
            if "which" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Which was the first computer with a hard disk drive", self.voice)
                self.sh.say("The answer is The IBM 305 RAMAC", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "when" in output or "launched" in output or "launch" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("When was the first computer with a hard disk drive launched", self.voice)
                self.sh.say("The answer is The IBM 305 RAMAC was launched in 1956", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "how" in output or "big" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("How big was the first hard disk drive", self.voice)
                self.sh.say("The answer is The IBM 305 RAMAC hard disk weighed over a ton and stored 5 MB of data", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
        if "what" in output and ("stand" in output or "stands" in output):
            self.sh.say("I heard the question", self.voice)
            self.sh.say("What does CAPTCHA stands for", self.voice)
            self.sh.say("The answer is CAPTCHA is an acronym for Completely Automated Public Turing test to tell Computers and Humans Apart", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "first" in output and "android" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("Who is the world's first android", self.voice)
            self.sh.say("The answer is Professor Kevin Warwick uses chips in his arm to operate doors, a robotic hand, and a wheelchair", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "mechanical" in output or "knight" in output or "night" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("What is a Mechanical Knight", self.voice)
            self.sh.say("The answer is A robot sketch made by Leonardo DaVinci", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "paradox" in output or "state" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("What does Moravec's paradox state", self.voice)
            self.sh.say("The answer is Moravec's paradox states that a computer can crunch numbers like Bernoulli, but lacks a toddler's motor skills", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "knowledge" in output or "engineering" in output or "bottle" in output or "neck" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("What is the AI knowledge engineering bottleneck", self.voice)
            self.sh.say("The answer is It is when you need to load an AI with enough knowledge to start learning", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True

        if "humanity" in output:
            if "worried" in output or "impact" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Why is Elon Musk is worried about AI's impact on humanity", self.voice)
                self.sh.say("The answer is I don't know. He should worry more about the people's impact on humanity", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "threat" in output or "robot" in output or "robots" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Do you think robots are a threat to humanity", self.voice)
                self.sh.say("The answer is No Humans are the real threat to humanity", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "why" in output:
            if "worried" in output or "impact" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Why is Elon Musk is worried about AI's impact on humanity", self.voice)
                self.sh.say("The answer is I don't know. He should worry more about the people's impact on humanity", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
        if "you" in output or "do" in output:
            if "threat" in output or "humanity" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Do you think robots are a threat to humanity", self.voice)
                self.sh.say("The answer is No Humans are the real threat to humanity", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
        if "what" in output and "chatbot" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("What is a chatbot", self.voice)
            self.sh.say("The answer is A chatbot is an A.I. you put in customer service to avoid paying salaries", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "car" in output and "safe" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("Are self-driving cars safe", self.voice)
            self.sh.say("The answer is Yes. Car accidents are product of human misconduct", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "robot" in output:
            if "mark" in output:
                self.sh.say("I heard the question", self.voice)
                self.sh.say("Is Mark Zuckerberg a robot", self.voice)
                self.sh.say("The answer is Sure. I've never seen him drink water", self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
        if "apple" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("Who is the inventor of the Apple I microcomputer", self.voice)
            self.sh.say("The answer is My lord and master Steve Wozniak", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True
        if "number" in output or "crowd" in output: #and ("people" in output or "person" in output or "persons" in output):
            if "male" in output:
                self.sh.say("I heard the question", self.voice)
                tmpAnswer = "the answer is that the male number is " + str(self.male_number)
                self.sh.say(tmpAnswer, self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "female" in output:
                self.sh.say("I heard the question", self.voice)
                tmpAnswer = "the answer is that the female number is " + str(self.female_number)
                self.sh.say(tmpAnswer, self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "all" in output or "total" in output:
                self.sh.say("I heard the question", self.voice)
                tmpAnswer = "the answer is that the total number of person is " + str(self.female_number + self.male_number)
                self.sh.say(tmpAnswer, self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "stand" in output or "standing" in output:
                self.sh.say("I heard the question", self.voice)
                tmpAnswer = "the answer is that the number of standing person is " + str(self.stand_number)
                self.sh.say(tmpAnswer, self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True
            if "sit" in output or "sitting" in output:
                self.sh.say("I heard the question", self.voice)
                tmpAnswer = "the answer is that the number of sitting person is " + str(self.sit_number)
                self.sh.say(tmpAnswer, self.voice)
                self.sh.say("Okay i am ready for your next question", self.voice)
                self.is_answer_question = True

        if "capital" in output:
            self.sh.say("I heard the question", self.voice)
            self.sh.say("What is capital of canada", self.voice)
            self.sh.say("The answer is The capital of Canada is Ottawa", self.voice)
            self.sh.say("Okay i am ready for your next question", self.voice)
            self.is_answer_question = True





    '''
    def parse_output(self, output):
        # 首先收集输出中的各类关键词
        # 首先收集输出中的各类关键词
        rospy.loginfo("Parsing output")
        for room in self.locations.keys():
            if room.lower() in output:
                self.target_room = room
        for person in self.names.keys():
            if person.lower() in output:
                self.target_person = person
        for Object in self.objects.keys():
            if Object.lower() in output:
                self.target_object = Object
                self.target_location = self.objects[Object]['location']
        for mission in self.missions:
            if mission in output:
                self.target_mission = mission
                
        rospy.loginfo("Detected following keywords")
        print ("Target room: "+self.target_room)
        print ("Target location: "+self.target_location)
        print ("Target object: "+self.target_object)
        print ("Target person: "+self.target_person)
        print ("Target mission: "+self.target_mission)


        # 根据接受到的关键词执行任务
        if self.target_room == None and self.target_object == None and self.target_mission == None:
            # 若没有接受到有关房间，物体，任务的关键词， 则判断需要回答问题
            self.answer_question(output)
            self.init_params()

        if self.target_room != None and self.target_person != None and self.target_mission == 'answer':
            # 若同时听到房间信息以及回答问题的要求
            # 一般会是要求机器人前往某个房间找到某个人，然后回答问题
            # 则先前往指定房间，在到达房间之后回答问题
            while(1):
                if self._room == UNSTART:
                    self.move_to_room()
                if self._room == FINISH and self._person == UNSTART:
                    self.find_person()
                if self._person == FINISH:
                    temp_str = "I have found " + str(self.target_person)
                    self.sh.say(temp_str, self.voice)
                    rospy.sleep(3)
                    # 播放初始化的音频，并提醒操作者如何使用语音操作Jack
                    self.sh.say("Hello my name is Jack", self.voice)
                    rospy.sleep(3)
                    self.sh.say("Please say Jack to wake me up before each question", self.voice)
                    rospy.sleep(4)
                    self.sh.say("I am ready for your question if you hear", self.voice)
                    rospy.sleep(3.5)
                    play_signal_sound()
                self.init_params()

        if self.target_room != None and self.target_object != None:
            # 若同时听到房间信息和物品信息
            # 则判断是要去某个房间找到或者抓取某个物体
            # 则先前往指定房间，然后找到指定物体
            while(1):
                if self._room == UNSTART:
                    self.move_to_room()
                if self._room == FINISH and self._location == UNSTART:
                    self.move_to_location()
                if self._location == FINISH and self._object == UNSTART:
                    self.find_object()
                self.init_params()
    '''




    def mission_excute(self):
        # 首先控制机器人移动到指定的房间

        # 首先判断是不是要求回答问题

        # 然后根据关键词对机器人进行相应的操作
        return 0


    def cleanup(self):
        rospy.loginfo("shuting down gpsr control node ....")

if __name__ == '__main__':
    rospy.init_node("gpsr_speech_control", anonymous=True)
    ctrl = gpsr_speech_control()
    rospy.spin()
