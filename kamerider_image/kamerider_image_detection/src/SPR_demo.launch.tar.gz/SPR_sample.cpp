//ros
#include <ros/ros.h>
#include <std_msgs/String.h>
#include <std_msgs/Int8.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
//c++
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
//kamerider_image_msgs
#include <kamerider_image_msgs/FaceDetection.h>
#include <kamerider_image_msgs/GenderDetection.h>
#include <kamerider_image_msgs/BoundingBox.h>
//std_msgs
#include <std_msgs/Bool.h>
#include <std_msgs/String.h>
#include <std_msgs/Int8.h>
//lamerider_navigation
#include <geometry_msgs/Twist.h>
#include <actionlib/client/simple_action_client.h>
#include <kamerider_navigation/turn_robotAction.h>
//soundplay
#include <sound_play/sound_play.h>

using namespace std;
using namespace cv;

//导航client
typedef actionlib::SimpleActionClient<kamerider_navigation::turn_robotAction> Client;

//navigation
bool is_turn_over;
void doneCallback(const actionlib::SimpleClientGoalState& state,
                   const kamerider_navigation::turn_robotResultConstPtr& result)
{
    ROS_INFO ("I have turned %f degree, waiting for your further command", result->final_angle);
    is_turn_over = true;
}
void activeCallback ()
{
    ROS_INFO ("Goal actived");
}
void feedbackCallback (const kamerider_navigation::turn_robotFeedbackConstPtr& feedback)
{
    ROS_INFO ("current angle is %f", feedback->current_angle);
}

class SPR
{
private:
  enum Step
  {
    Start,
    Turn,
    Detect_Face_Gender,
    Play_Riddle,
    Circling_Crowd,
    Leave,
  };

  int step;
  const float PI = 3.1415926;
  //bool is_receive_face_detect_result;
  bool is_receive_gender_detect_result;
  //bool is_turn_over;
  bool is_pub_take_photo_signal;

  //kamerider_image_msgs::FaceDetection face_detection_msg;
  kamerider_image_msgs::GenderDetection gender_detection_msg;

  void init()
  {
    step = Start;
    //is_receive_face_detect_result = false;
    is_receive_gender_detect_result = false;
    is_pub_take_photo_signal = false;
  }

  void gender_detection_callback(const kamerider_image_msgs::GenderDetection msg)
  {
    ROS_INFO("RECEIVE THE GENDER DETECTION RESULTS");
    gender_detection_msg.male_num = msg.male_num;
    gender_detection_msg.female_num = msg.female_num;
    gender_detection_msg.sit_num = msg.sit_num;
    gender_detection_msg.stand_num = msg.stand_num;
    is_receive_gender_detect_result = true;
  }

  void publish_take_photo_signal(ros::Publisher &publisher)
  {
    //if(!msg)
    //{
      ROS_INFO("PUBLISH TAKE_PHOTO_SIGNAL");
      std_msgs::String is_take_photo_msg;
      is_take_photo_msg.data = "take_photo";
      publisher.publish(is_take_photo_msg);
      //is_take_photo = true;
    //}
  }

public:
  int run(int argc, char **argv)
  {
    ros::init(argc, argv, "SPR_sample");

    ros::NodeHandle node;
    //语音客户端
    sound_play::SoundClient sound_client;

    //advertise topics
    string pub_take_photo_signal_topic_name;

    //subscribe topics
    string sub_gender_recognition_topic_name;

    node.param<string>("pub_take_photo_signal_topic_name",  pub_take_photo_signal_topic_name,  "/take_photo_signal");
    node.param<string>("sub_gender_recognition_topic_name", sub_gender_recognition_topic_name, "/kamerider_image/gender_recognition");

    ros::Publisher take_photo_signal = node.advertise<std_msgs::String>(pub_take_photo_signal_topic_name, 10);

    ros::Subscriber gender_detection = node.subscribe<kamerider_image_msgs::GenderDetection>(sub_gender_recognition_topic_name, 10, &SPR::gender_detection_callback, this);

    init();

    while(ros::ok())
    {
      switch(step)
      {
        case Start:
        {
          cout<<"======================================="<<endl;
          ROS_INFO("START SPEECH AND PERSON RECOGNITION");
          ros::Duration(1).sleep();
          sound_client.say("Hello I wanna play riddles");
          ros::Duration(3).sleep();
          sound_client.say("I will turn back after ten seconds");
          ros::Duration(3).sleep();
          sound_client.say("ten");
          ros::Duration(1).sleep();
          sound_client.say("nine");
          ros::Duration(1).sleep();
          sound_client.say("eight");
          ros::Duration(1).sleep();
          sound_client.say("seven");
          ros::Duration(1).sleep();
          sound_client.say("six");
          ros::Duration(1).sleep();
          sound_client.say("five");
          ros::Duration(1).sleep();
          sound_client.say("four");
          ros::Duration(1).sleep();
          sound_client.say("three");
          ros::Duration(1).sleep();
          sound_client.say("two");
          ros::Duration(1).sleep();
          sound_client.say("one");
          ros::Duration(1).sleep();
          //want to play riddle
          step++;
          //step = step + 2;
          break;
        }
        case Turn:
        {
          cout<<"======================================="<<endl;
          ROS_INFO("READY TO TURN");
          Client client("turn_robot", true);
          ROS_INFO ("Waiting for action server to start");
          client.waitForServer();
          ROS_INFO ("Action server actived, start sending goal");

          kamerider_navigation::turn_robotGoal goal;
          goal.goal_angle = PI;
          client.sendGoal(goal, doneCallback, activeCallback, feedbackCallback);
          if(is_turn_over)
          {
            step++;
            is_turn_over = false;
          }
          break;
          //ros::spinOnce();
        }
        case Detect_Face_Gender:
        {
          //is_take_photo = true;
          if(is_receive_gender_detect_result)
          {
            cout<<"======================================="<<endl;
            int male_num = gender_detection_msg.male_num;
            int female_num = gender_detection_msg.female_num;
            int sit_num = gender_detection_msg.sit_num;
            int stand_num = gender_detection_msg.stand_num;
            int face_num = male_num + female_num;
            ROS_INFO("face_num = %d", face_num);
            ROS_INFO("male_num = %d", male_num);
            ROS_INFO("female_num = %d", female_num);
            ROS_INFO("sit_num = %d", sit_num);
            ROS_INFO("stand_num = %d", stand_num);
            /*sound_client.say("face_num is %d", face_num);
            sound_client.say("male_num is %d", malee_num);
            sound_client.say("female_num is %d", female_num);
            sound_client.say("sit_num is %d", sit_num);
            sound_client.say("stand_num is %d", stand_num);*/
            //char *str = 'face_num is ' + face_num;
            //sound_client.repeat(str);
            ros::Duration(1).sleep();
            sound_client.say("I have taken a picture");
            ros::Duration(1).sleep();
            sound_client.say("Here are the results");
            ros::Duration(1).sleep();

            string str = "The face number is " + to_string(face_num);
            sound_client.say(str);
            ros::Duration(1).sleep();

            str = "The male number is " + to_string(male_num);
            sound_client.say(str);
            ros::Duration(1).sleep();

            str = "The female number is " + to_string(female_num);
            sound_client.say(str);
            ros::Duration(1).sleep();

            str = "The number of sitting persons is " + to_string(sit_num);
            sound_client.say(str);
            ros::Duration(1).sleep();

            str = "The number of standing persons is " + to_string(stand_num);
            sound_client.say(str);
            ros::Duration(1).sleep();

            //is_receive_gender_detect_result = false;
            //speak
            step++;
          }
          else
          {
            publish_take_photo_signal(take_photo_signal);
          }
          break;
        }
        case Play_Riddle:
        {

        }
        case Circling_Crowd:
        {

        }
        case Leave:
        {

        }

      }//end switch
      ros::spinOnce();
    }//end while
    return EXIT_SUCCESS;

  }//end run
};



int main(int argc, char **argv)
{
  //ros::init(argc, argv, "Speech_and_Person_Recognition");
  //ros::NodeHandle SPR_node;
  SPR SPR_sample;
  return SPR_sample.run(argc, argv);
}
